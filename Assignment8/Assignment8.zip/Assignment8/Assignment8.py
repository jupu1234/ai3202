from HMMfunc import *

prob = HMMfunc("typos20.data")
prob.calcocc()
prob.printdata()


