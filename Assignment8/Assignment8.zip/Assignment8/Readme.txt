Just need to run the Purtell_Assignment8.py file
It outputs to Assignment8out.txt file
